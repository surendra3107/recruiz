package com.bbytes.recruiz.enums;

public enum Vertical {

	IT ,
	RIM,
	BPO,
	Telecom,
	Retail,
	BFSI,
	Biotech,
	Manufacturing,
	Engineering,
	Services,
	Automotive,
	Aerospace,
	Hospitality,
	Entertainment,
	Analytics;
}
