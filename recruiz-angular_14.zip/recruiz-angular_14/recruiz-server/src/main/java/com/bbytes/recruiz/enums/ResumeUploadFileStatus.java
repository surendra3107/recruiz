package com.bbytes.recruiz.enums;

public enum ResumeUploadFileStatus {

	PENDING, PROCESSING,SUCCESS, FAILED;

}
