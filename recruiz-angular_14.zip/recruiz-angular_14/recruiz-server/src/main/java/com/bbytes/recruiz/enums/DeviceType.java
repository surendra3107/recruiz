package com.bbytes.recruiz.enums;

public enum DeviceType {

	MOBILE_OR_TABLET , WEB 
}
