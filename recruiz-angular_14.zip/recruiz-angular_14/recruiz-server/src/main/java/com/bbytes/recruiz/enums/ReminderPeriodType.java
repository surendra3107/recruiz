package com.bbytes.recruiz.enums;

public enum ReminderPeriodType {

	Minutes, Hours, Days;

}
