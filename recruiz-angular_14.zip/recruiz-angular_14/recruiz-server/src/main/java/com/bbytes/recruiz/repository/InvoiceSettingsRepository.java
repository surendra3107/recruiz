package com.bbytes.recruiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bbytes.recruiz.domain.InvoiceSettings;

public interface InvoiceSettingsRepository extends JpaRepository<InvoiceSettings, Long> {

	
}
