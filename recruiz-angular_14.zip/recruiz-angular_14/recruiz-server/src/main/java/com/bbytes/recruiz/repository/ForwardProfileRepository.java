package com.bbytes.recruiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bbytes.recruiz.domain.ForwardProfile;

public interface ForwardProfileRepository extends JpaRepository<ForwardProfile, Long> {

}
