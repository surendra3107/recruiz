package com.bbytes.recruiz.exception;

public class RecruizEmptySearchCriteriaException extends Exception {

	private static final long serialVersionUID = -2317729349964250645L;

	public RecruizEmptySearchCriteriaException() {
		super();
	}
}
