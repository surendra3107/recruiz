package com.bbytes.recruiz.enums;

public enum Gender {

	Male("M"), Female("F");

	String gender;

	private Gender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

}
