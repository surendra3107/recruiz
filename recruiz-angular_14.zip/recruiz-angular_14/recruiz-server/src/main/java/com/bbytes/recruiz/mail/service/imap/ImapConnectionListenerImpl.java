//package com.bbytes.recruiz.mail.service.imap;
//
//import java.util.List;
//
//import com.lafaspot.imapnio.client.IMAPSession;
//import com.lafaspot.imapnio.listener.IMAPConnectionListener;
//import com.sun.mail.imap.protocol.IMAPResponse;
//
//public class ImapConnectionListenerImpl implements IMAPConnectionListener{
//
//	@Override
//	public void onConnect(IMAPSession arg0) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void onDisconnect(IMAPSession arg0, Throwable arg1) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void onInactivityTimeout(IMAPSession arg0) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void onMessage(IMAPSession arg0, IMAPResponse arg1) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void onResponse(IMAPSession arg0, String arg1, List<IMAPResponse> arg2) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}
