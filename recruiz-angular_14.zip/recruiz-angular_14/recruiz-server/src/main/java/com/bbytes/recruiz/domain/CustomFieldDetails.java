package com.bbytes.recruiz.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CustomFieldDetails {

	public String fieldName;
	
	public String fieldValue;
	
}
