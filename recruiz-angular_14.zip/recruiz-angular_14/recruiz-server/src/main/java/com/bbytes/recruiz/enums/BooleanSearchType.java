package com.bbytes.recruiz.enums;

public enum BooleanSearchType {

	AND, OR, NOT;
}
