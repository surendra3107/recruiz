package com.bbytes.recruiz.enums;

public enum Communication {

	Excellent, Good, Average, Poor;

}
