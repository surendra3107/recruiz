package com.bbytes.recruiz.enums;

public enum WebRequestMode {

	WEB_APP , API, PLUGIN
}
