package com.bbytes.recruiz.enums;

public enum DefaultRounds {

	Sourcing("Sourcing");

	String displayName;

	private DefaultRounds(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName
	 *            the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

}
