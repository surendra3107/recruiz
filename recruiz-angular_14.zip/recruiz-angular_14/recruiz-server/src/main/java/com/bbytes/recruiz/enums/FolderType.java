package com.bbytes.recruiz.enums;

public enum FolderType {

	CANDIDATE_FOLDER, POSITION_FOLDER;

}
