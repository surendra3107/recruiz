package com.bbytes.recruiz.rest.dto.models;

import lombok.Data;

@Data
public class CandidateApplyFormFieldsDTO {

	String id;
	String isMandatory;
}
