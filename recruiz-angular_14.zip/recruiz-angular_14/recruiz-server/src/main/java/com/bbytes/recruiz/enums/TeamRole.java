package com.bbytes.recruiz.enums;

public enum TeamRole {

	member , team_leader , team_manager;

	
}
